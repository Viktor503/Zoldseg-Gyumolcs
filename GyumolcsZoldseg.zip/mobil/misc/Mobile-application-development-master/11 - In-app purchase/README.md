# Alkalmazáson belüli vásárlások, publikálás

## Felhasznált források

* https://medium.com/android-news/everything-you-need-to-know-about-google-plays-in-app-billing-29b728a32822
* https://learn.buildfire.com/en/articles/2534938-how-to-create-a-subscription-in-app-purchase-for-android
* https://learn.buildfire.com/en/articles/2534933-how-to-create-a-single-in-app-purchase-for-android
* https://learn.buildfire.com/en/articles/499662-how-to-set-up-your-account-for-in-app-purchases-in-your-google-developer-account-for-android
* https://betterprogramming.pub/how-to-implement-in-app-purchases-in-your-android-app-7cc1f80148a4
* https://developer.android.com/google/play/billing/integrate
* https://developer.android.com/google/play/billing/getting-ready
* https://play.google.com/intl/au/console/about/release/
* https://github.com/pavan5208/android_in_app_purchase_sample
*

## Ami lemaradt - Publikálás

* https://stackoverflow.com/questions/20268520/generate-signed-apk-android-studio
* https://developer.android.com/studio/publish
