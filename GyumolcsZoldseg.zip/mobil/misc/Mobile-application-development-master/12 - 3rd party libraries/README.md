# Libraries

Források:
- https://github.com/ddanny/achartengine
- https://www.baeldung.com/intro-to-project-lombok
- https://github.com/JakeWharton/butterknife