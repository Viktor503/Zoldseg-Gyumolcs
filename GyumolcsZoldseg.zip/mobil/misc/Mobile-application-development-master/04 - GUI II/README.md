# Android Shop

Források:

- https://developer.android.com/codelabs/android-training-create-an-activity?index=..%2F..%2Fandroid-training#0
- https://developer.android.com/codelabs/android-training-activity-lifecycle-and-state?index=..%2F..%2Fandroid-training#0
- https://developer.android.com/codelabs/android-training-clickable-images?index=..%2F..%2Fandroid-training#0
- https://developer.android.com/codelabs/android-training-input-controls?index=..%2F..%2Fandroid-training#0

Képek:

- https://github.com/google-developer-training/android-fundamentals-apps-v2/tree/master/DroidCafe/app/src/main/res/drawable