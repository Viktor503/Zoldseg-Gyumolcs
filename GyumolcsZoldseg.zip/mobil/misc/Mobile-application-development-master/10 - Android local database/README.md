# Words Sample app

## Források

* https://developer.android.com/codelabs/android-training-livedata-viewmodel?index=..%2F..%2Fandroid-training
* https://developer.android.com/codelabs/android-training-room-delete-data?index=..%2F..%2Fandroid-training
