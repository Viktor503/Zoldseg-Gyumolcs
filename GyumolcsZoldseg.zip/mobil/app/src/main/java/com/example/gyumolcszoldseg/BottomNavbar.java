package com.example.gyumolcszoldseg;

public class BottomNavbar {

}
