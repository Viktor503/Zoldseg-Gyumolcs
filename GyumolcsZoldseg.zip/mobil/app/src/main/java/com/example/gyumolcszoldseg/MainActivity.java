package com.example.gyumolcszoldseg;

import android.os.Bundle;

import androidx.navigation.ui.AppBarConfiguration;


public class MainActivity extends baseActivity {

    private AppBarConfiguration appBarConfiguration;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

}