package com.example.gyumolcszoldseg;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toolbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class baseActivity extends AppCompatActivity {
    @Override
        public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.bottom_menu, menu);
        setSupportActionBar(findViewById(R.id.bottomAppBar));
        return true;
        }

    protected Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        toolbar = findViewById(R.id.bottomAppBar); // Assuming your toolbar has this id
        setSupportActionBar(toolbar);

    }



    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
            System.out.println("Menu item selected");
            switch (item.getItemId()) {
            case R.id.home:
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            finish();
            return true;
            case R.id.shop:
            Intent intent2 = new Intent(this, ShopActivity.class);
            startActivity(intent2);
            finish();
            return true;
            case R.id.account:
            Intent intent3 = new Intent(this, ProfileActivity.class);
            startActivity(intent3);
            finish();
            return true;
                    /*
                case R.id.cart:
                    Intent intent4 = new Intent(MainActivity.this, CartActivity.class);
                    startActivity(intent4);
                    return true;

                     */
            }
            return super.onOptionsItemSelected(item);
            }
}
